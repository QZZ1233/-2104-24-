package com.sdut.supermarket.pojo.query;

public class GoodQuery {
    private Integer page;
    private Integer limit;
    private String name;
    private String supplier;

    public GoodQuery() {
    }

    public GoodQuery(Integer page, Integer limit, String name, String supplier) {
        this.page = page;
        this.limit = limit;
        this.name = name;
        this.supplier = supplier;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }
}
