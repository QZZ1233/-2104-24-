package com.sdut.supermarket.pojo;

import java.util.Date;

public class Emp {
    private Integer id;
    private String name;
    private String email;
    private String phone;
    //所在部门id
    private Integer deptId;
    private Integer deleted;
    private Date gmtCreate;
    private Date gmtModified;

    public Emp() {
    }

    public Emp(Integer id, String name, String email,
               String phone, Integer deptId, Integer deleted,
               Date gmtCreate, Date gmtModified) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.deptId = deptId;
        this.deleted = deleted;
        this.gmtCreate = gmtCreate;
        this.gmtModified = gmtModified;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
