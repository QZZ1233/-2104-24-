package com.sdut.supermarket.pojo;

import java.util.Date;

public class Dept {
    private Integer id;
    private String name;
    private String addr;
    private Integer deleted;
    private Date gmtCreate;
    private Date gmtModified;

    public Dept() {
    }

    public Dept(Integer id, String name, String addr, Integer deleted, Date gmtCreate, Date gmtModified) {
        this.id = id;
        this.name = name;
        this.addr = addr;
        this.deleted = deleted;
        this.gmtCreate = gmtCreate;
        this.gmtModified = gmtModified;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
