package com.sdut.supermarket.pojo.vo;

public class GoodSupplierVO {
    private Integer id;
    private String name;
    private Integer num;
    private Float price;
    private String qgp;
    private String sName;

    public GoodSupplierVO() {
    }

    public GoodSupplierVO(Integer id, String name, Integer num, Float price, String qgp, String sName) {
        this.id = id;
        this.name = name;
        this.num = num;
        this.price = price;
        this.qgp = qgp;
        this.sName = sName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public String getQgp() {
        return qgp;
    }

    public void setQgp(String qgp) {
        this.qgp = qgp;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    @Override
    public String toString() {
        return "GoodSupplierVO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", num=" + num +
                ", price=" + price +
                ", qgp=" + qgp +
                ", sName='" + sName + '\'' +
                '}';
    }
}
