package com.sdut.supermarket.pojo;

import java.util.Date;

public class Good {
    private Integer id;
    private String name;
    private Integer num;
    private Float price;
    private Date qgp;   //保质日期
    private Integer sid;

    public Good() {
    }

    public Good(Integer id, String name, Integer num, Float price, Date qgp, Integer sid) {
        this.id = id;
        this.name = name;
        this.num = num;
        this.price = price;
        this.qgp = qgp;
        this.sid = sid;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Date getQgp() {
        return qgp;
    }

    public void setQgp(Date qgp) {
        this.qgp = qgp;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }
}
