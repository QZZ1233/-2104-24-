package com.sdut.supermarket.pojo.query;

public class DeptQuery {
    private Integer page;
    private Integer limit;
    private String name;
    private String addr;

    public DeptQuery() {
    }

    public DeptQuery(Integer page, Integer limit, String name, String addr) {
        this.page = page;
        this.limit = limit;
        this.name = name;
        this.addr = addr;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }
}
