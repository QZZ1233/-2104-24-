package com.sdut.supermarket.pojo.query;

public class EmpQuery {
    private Integer page;
    private Integer limit;
    private String name;
    private String email;
    private String phone;

    public EmpQuery() {
    }

    public EmpQuery(Integer page, Integer limit, String name, String email, String phone) {
        this.page = page;
        this.limit = limit;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
