package com.sdut.supermarket.service.impl;

import com.sdut.supermarket.dao.IDeptDao;
import com.sdut.supermarket.dao.impl.DeptDaoImpl;
import com.sdut.supermarket.pojo.Dept;
import com.sdut.supermarket.pojo.query.DeptQuery;
import com.sdut.supermarket.pojo.vo.DeptCountVO;
import com.sdut.supermarket.service.IDeptService;
import com.sdut.supermarket.utils.JSONResult;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public class DeptServiceImpl implements IDeptService {
    private IDeptDao deptDao = new DeptDaoImpl();

    @Override
    public List<Dept> selectAll() {
        return deptDao.selectAll();
    }

    @Override
    public LayUITableResult selectByPage(DeptQuery deptQuery) {
        //查询当前页的数据
        List<Dept> list = deptDao.selectByPage(deptQuery);
        //查询总的数量
        Long totalCount = deptDao.selectTotalCount(deptQuery);
        return LayUITableResult.ok(list, totalCount);
    }

    @Override
    public Boolean deleteById(Integer id) {
        Integer count = deptDao.deleteById(id);
        return count == 1;
    }

    @Override
    public Boolean deleteAll(String[] array) {
        Integer[] ids = new Integer[array.length];
        for (int i = 0; i < array.length; i++) {
            ids[i] = Integer.parseInt(array[i]);
        }

        int count = deptDao.deleteAll(ids);
        return count == array.length;
    }

    @Override
    public Boolean add(Dept dept) {
        int count = deptDao.add(dept);
        return count == 1;
    }

    @Override
    public Dept selectById(int id) {
        return deptDao.selectById(id);
    }

    @Override
    public Boolean update(Dept dept) {
        int count = deptDao.update(dept);
        return count == 1;
    }

    @Override
    public JSONResult selectDeptCount() {
        List<DeptCountVO> list = deptDao.selectDeptCount();
        return JSONResult.ok(list);
    }
}
