package com.sdut.supermarket.service;

import com.sdut.supermarket.pojo.User;
import com.sdut.supermarket.pojo.query.UserQuery;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public interface IUserService {
    List<User> selectAll();

    LayUITableResult selectByPage(UserQuery userQuery);

    Boolean deleteById(Integer id);

    Boolean deleteAll(String[] array);

    Boolean add(User user);

    User selectById(int id);

    Boolean update(User user);

    User login(String name, String password);

    Boolean updateStatus(String id, Integer status);
}
