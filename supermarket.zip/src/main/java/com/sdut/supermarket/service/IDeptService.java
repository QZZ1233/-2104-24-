package com.sdut.supermarket.service;


import com.sdut.supermarket.pojo.Dept;
import com.sdut.supermarket.pojo.query.DeptQuery;
import com.sdut.supermarket.utils.JSONResult;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public interface IDeptService {
    List<Dept> selectAll();

    LayUITableResult selectByPage(DeptQuery deptQuery);

    Boolean deleteById(Integer id);

    Boolean deleteAll(String[] array);

    Boolean add(Dept dept);

    Dept selectById(int id);

    Boolean update(Dept dept);

    JSONResult selectDeptCount();
}
