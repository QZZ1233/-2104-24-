package com.sdut.supermarket.service.impl;


import com.sdut.supermarket.dao.IEmpDao;
import com.sdut.supermarket.dao.impl.EmpDaoImpl;
import com.sdut.supermarket.pojo.Emp;
import com.sdut.supermarket.pojo.query.EmpQuery;
import com.sdut.supermarket.pojo.vo.EmpDeptVO;
import com.sdut.supermarket.service.IEmpService;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public class EmpServiceImpl implements IEmpService {
    private IEmpDao empDao = new EmpDaoImpl();

    @Override
    public List<Emp> selectAll() {
        return empDao.selectAll();
    }

    @Override
    public LayUITableResult selectByPage(EmpQuery empQuery) {
        //查询当前页的数据
        List<EmpDeptVO> list = empDao.selectByPage(empQuery);
        //查询总的数量
        Long totalCount = empDao.selectTotalCount(empQuery);
        return LayUITableResult.ok(list, totalCount);
    }

    @Override
    public Boolean deleteById(Integer id) {
        Integer count = empDao.deleteById(id);
        //return count == 1 ? true : false;
        return count == 1;
    }

    @Override
    public Boolean deleteAll(String[] array) {
        Integer[] ids = new Integer[array.length];
        for (int i = 0; i < array.length; i++) {
            ids[i] = Integer.parseInt(array[i]);
        }

        int count = empDao.deleteAll(ids);
        return count == array.length;
    }

    @Override
    public Boolean add(Emp emp) {
        int count = empDao.add(emp);
        return count == 1;
    }

    @Override
    public Emp selectById(int id) {
        return empDao.selectById(id);
    }

    @Override
    public Boolean update(Emp emp) {
        int count = empDao.update(emp);
        return count == 1;
    }
}