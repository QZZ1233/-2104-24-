package com.sdut.supermarket.service;


import com.sdut.supermarket.pojo.Good;
import com.sdut.supermarket.pojo.query.GoodQuery;
import com.sdut.supermarket.utils.LayUITableResult;

public interface IGoodService {

    LayUITableResult selectByPage(GoodQuery goodQuery);

    Boolean deleteById(Integer id);

    Boolean deleteAll(String[] array);

    Boolean add(Good good);

    Good selectById(int id);

    Boolean update(Good good);
}
