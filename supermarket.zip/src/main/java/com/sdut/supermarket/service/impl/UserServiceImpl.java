package com.sdut.supermarket.service.impl;

import com.sdut.supermarket.dao.IUserDao;
import com.sdut.supermarket.dao.impl.UserDaoImpl;
import com.sdut.supermarket.pojo.User;
import com.sdut.supermarket.pojo.query.UserQuery;
import com.sdut.supermarket.service.IUserService;
import com.sdut.supermarket.utils.LayUITableResult;
import com.sdut.supermarket.utils.MD5Util;

import java.util.List;


public class UserServiceImpl implements IUserService {
    private IUserDao userDao = new UserDaoImpl();

    @Override
    public List<User> selectAll() {
        return userDao.selectAll();
    }

    @Override
    public LayUITableResult selectByPage(UserQuery userQuery) {
        //查询当前页的数据
        List<User> list = userDao.selectByPage(userQuery);
        //查询总的数量
        Long totalCount = userDao.selectTotalCount(userQuery);
        return LayUITableResult.ok(list, totalCount);
    }

    @Override
    public Boolean deleteById(Integer id) {
        //return count == 1 ? true : false;
        return userDao.deleteById(id) == 1;
    }

    @Override
    public Boolean deleteAll(String[] array) {
        Integer[] ids = new Integer[array.length];
        for (int i = 0; i < array.length; i++) {
            ids[i] = Integer.parseInt(array[i]);
        }

        int count = userDao.deleteAll(ids);
        return count == array.length;
    }

    @Override
    public Boolean add(User user) {
        //添加用户时候将密码以密文的形式保存到数据库中
        user.setPassword(MD5Util.MD5Encode(user.getPassword() + MD5Util.MD5_SALT));
        int count = userDao.add(user);
        return count == 1;
    }

    @Override
    public User selectById(int id) {
        return userDao.selectById(id);
    }

    @Override
    public Boolean update(User user) {
        int count = userDao.update(user);
        return count == 1;
    }

    @Override
    public User login(String name, String password) {
        return userDao.login(name, password);
    }

    @Override
    public Boolean updateStatus(String id, Integer status) {
        int count = userDao.updateStatus(id, status);
        return count == 1;
    }
}
