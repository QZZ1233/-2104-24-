package com.sdut.supermarket.service;


import com.sdut.supermarket.pojo.Supplier;
import com.sdut.supermarket.pojo.query.SupplierQuery;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public interface ISupplierService {
    List<Supplier> selectAll();

    LayUITableResult selectByPage(SupplierQuery supplierQuery);

    Boolean deleteById(Integer id);

    Boolean deleteAll(String[] array);

    Boolean add(Supplier supplier);

    Supplier selectById(int id);

    Boolean update(Supplier emp);
}
