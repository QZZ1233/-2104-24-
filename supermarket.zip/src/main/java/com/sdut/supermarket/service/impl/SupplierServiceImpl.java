package com.sdut.supermarket.service.impl;

import com.sdut.supermarket.dao.ISupplierDao;
import com.sdut.supermarket.dao.impl.SupplierDaoImpl;
import com.sdut.supermarket.pojo.Supplier;
import com.sdut.supermarket.pojo.query.SupplierQuery;
import com.sdut.supermarket.service.ISupplierService;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public class SupplierServiceImpl implements ISupplierService {
    private ISupplierDao supplierDao = new SupplierDaoImpl();

    @Override
    public List<Supplier> selectAll() {
        return supplierDao.selectAll();
    }

    @Override
    public LayUITableResult selectByPage(SupplierQuery supplierQuery) {
        //查询当前页的数据
        List<Supplier> list = supplierDao.selectByPage(supplierQuery);
        //查询总的数量
        Long totalCount = supplierDao.selectTotalCount(supplierQuery);
        return LayUITableResult.ok(list, totalCount);
    }

    @Override
    public Boolean deleteById(Integer id) {
        Integer count = supplierDao.deleteById(id);
        //return count == 1 ? true : false;
        return count == 1;
    }

    @Override
    public Boolean deleteAll(String[] array) {
        Integer[] ids = new Integer[array.length];
        for (int i = 0; i < array.length; i++) {
            ids[i] = Integer.parseInt(array[i]);
        }

        int count = supplierDao.deleteAll(ids);
        return count == array.length;
    }

    @Override
    public Boolean add(Supplier supplier) {
        int count = supplierDao.add(supplier);
        return count == 1;
    }

    @Override
    public Supplier selectById(int id) {
        return supplierDao.selectById(id);
    }

    @Override
    public Boolean update(Supplier emp) {
        int count = supplierDao.update(emp);
        return count == 1;
    }
}
