package com.sdut.supermarket.service.impl;


import com.sdut.supermarket.dao.IGoodDao;
import com.sdut.supermarket.dao.impl.GoodDaoImpl;
import com.sdut.supermarket.pojo.Good;
import com.sdut.supermarket.pojo.query.GoodQuery;
import com.sdut.supermarket.pojo.vo.GoodSupplierVO;
import com.sdut.supermarket.service.IGoodService;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public class GoodServiceImpl implements IGoodService {
    private IGoodDao goodDao = new GoodDaoImpl();


    @Override
    public LayUITableResult selectByPage(GoodQuery goodQuery) {
        //查询当前页的数据
        List<GoodSupplierVO> list = goodDao.selectByPage(goodQuery);
        //查询总的数量
        Long totalCount = goodDao.selectTotalCount(goodQuery);
        return LayUITableResult.ok(list, totalCount);
    }

    @Override
    public Boolean deleteById(Integer id) {
        Integer count = goodDao.deleteById(id);
        //return count == 1 ? true : false;
        return count == 1;
    }

    @Override
    public Boolean deleteAll(String[] array) {
        Integer[] ids = new Integer[array.length];
        for (int i = 0; i < array.length; i++) {
            ids[i] = Integer.parseInt(array[i]);
        }

        int count = goodDao.deleteAll(ids);
        return count == array.length;
    }

    @Override
    public Boolean add(Good good) {
        int count = goodDao.add(good);
        return count == 1;
    }

    @Override
    public Good selectById(int id) {
        return goodDao.selectById(id);
    }

    @Override
    public Boolean update(Good emp) {
        int count = goodDao.update(emp);
        return count == 1;
    }
}
