package com.sdut.supermarket.service;


import com.sdut.supermarket.pojo.Emp;
import com.sdut.supermarket.pojo.query.EmpQuery;
import com.sdut.supermarket.utils.LayUITableResult;

import java.util.List;

public interface IEmpService {
    List<Emp> selectAll();

    LayUITableResult selectByPage(EmpQuery empQuery);

    Boolean deleteById(Integer id);

    Boolean deleteAll(String[] array);

    Boolean add(Emp emp);

    Emp selectById(int id);

    Boolean update(Emp emp);
}
