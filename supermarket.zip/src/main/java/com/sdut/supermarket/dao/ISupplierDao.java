package com.sdut.supermarket.dao;

import com.sdut.supermarket.pojo.Supplier;
import com.sdut.supermarket.pojo.query.SupplierQuery;

import java.util.List;

public interface ISupplierDao {
    List<Supplier> selectAll();

    List<Supplier> selectByPage(SupplierQuery supplierQuery);

    Long selectTotalCount(SupplierQuery supplierQuery);

    Integer deleteById(Integer id);

    Integer deleteAll(Integer[] ids);

    Integer add(Supplier emp);

    Supplier selectById(int id);

    Integer update(Supplier emp);
}
