package com.sdut.supermarket.dao;

import com.sdut.supermarket.pojo.Good;
import com.sdut.supermarket.pojo.query.GoodQuery;
import com.sdut.supermarket.pojo.vo.GoodSupplierVO;

import java.util.List;

public interface IGoodDao {
    List<GoodSupplierVO> selectByPage(GoodQuery goodQuery);

    Long selectTotalCount(GoodQuery goodQuery);

    Integer deleteById(Integer id);

    Integer deleteAll(Integer[] ids);

    Integer add(Good good);

    Good selectById(int id);

    Integer update(Good emp);
}
