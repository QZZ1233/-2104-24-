package com.sdut.supermarket.dao.impl;

import com.sdut.supermarket.dao.ISupplierDao;
import com.sdut.supermarket.pojo.Supplier;
import com.sdut.supermarket.pojo.query.SupplierQuery;
import com.sdut.supermarket.utils.JDBCUtil;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class SupplierDaoImpl implements ISupplierDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());

    @Override
    public List<Supplier> selectAll() {
        String sql = "select id, name, email, phone from supplier";
        System.out.println(sql);

        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Supplier.class));
    }

    @Override
    public List<Supplier> selectByPage(SupplierQuery supplierQuery) {
        String sql = "select id, name, email, phone from supplier ";

        //查询参数
        List<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(supplierQuery.getName())) {
            where += "and name like ?";
            args.add("%" + supplierQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(supplierQuery.getEmail())) {
            where += "and email=?";
            args.add(supplierQuery.getEmail());
        }
        if (!StringUtils.isEmpty(supplierQuery.getPhone())) {
            where += "and phone=?";
            args.add(supplierQuery.getPhone());
        }

        String limit;
        int offset = (supplierQuery.getPage() - 1) * supplierQuery.getLimit();
        limit = "order by id asc limit " + offset + "," + supplierQuery.getLimit();
        System.out.println(sql + where + limit);
        return jdbcTemplate.query(sql + where + limit, new BeanPropertyRowMapper<>(Supplier.class), args.toArray());
    }

    @Override
    public Long selectTotalCount(SupplierQuery supplierQuery) {
        System.out.println("start");
        // <where> <if></if> </where>
        //这三个搜索条件应该是有值才拼接上，没有值就不拼接
        String sql = "select count(*) from supplier ";

        //查询参数
        ArrayList<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(supplierQuery.getName())) {
            where += "and name like ?";
            args.add("%" + supplierQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(supplierQuery.getEmail())) {
            where += "and email=?";
            args.add(supplierQuery.getEmail());
        }
        if (!StringUtils.isEmpty(supplierQuery.getPhone())) {
            where += "and phone=?";
            args.add(supplierQuery.getPhone());
        }

        return jdbcTemplate.queryForObject(sql + where, Long.class, args.toArray());
    }

    @Override
    public Integer deleteById(Integer id) {
        String sql = "delete from supplier where id=?";
        return jdbcTemplate.update(sql, id);
    }

    @Override
    public Integer deleteAll(Integer[] ids) {
        String sql = "delete from supplier where id in(";
        for (Integer id : ids) {
            sql += "?,";
        }
        sql = sql.substring(0, sql.length() - 1);
        sql += ")";
        return jdbcTemplate.update(sql, ids);
    }

    @Override
    public Integer add(Supplier supplier) {
        String sql = "insert into supplier(name,email,phone) values(?,?,?)";
        System.out.println(sql);
        return jdbcTemplate.update(sql, supplier.getName(), supplier.getEmail(), supplier.getPhone());
    }

    @Override
    public Supplier selectById(int id) {
        String sql = "select id,name,email,phone from supplier where id=?";
        List<Supplier> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Supplier.class), id);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public Integer update(Supplier emp) {
        String sql = "update supplier set name=?,email=?,phone=? where id=?";
        return jdbcTemplate.update(sql, emp.getName(), emp.getEmail(), emp.getPhone(), emp.getId());
    }
}
