package com.sdut.supermarket.dao;

import com.sdut.supermarket.pojo.Dept;
import com.sdut.supermarket.pojo.query.DeptQuery;
import com.sdut.supermarket.pojo.vo.DeptCountVO;

import java.util.List;

public interface IDeptDao {
    List<Dept> selectAll();

    List<Dept> selectByPage(DeptQuery deptQuery);

    Long selectTotalCount(DeptQuery deptQuery);

    Integer deleteById(Integer id);

    Integer deleteAll(Integer[] ids);

    Integer add(Dept dept);

    Dept selectById(int id);

    Integer update(Dept dept);

    List<DeptCountVO> selectDeptCount();
}
