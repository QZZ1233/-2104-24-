package com.sdut.supermarket.dao.impl;

import com.sdut.supermarket.dao.IGoodDao;
import com.sdut.supermarket.pojo.Good;
import com.sdut.supermarket.pojo.query.GoodQuery;
import com.sdut.supermarket.pojo.vo.GoodSupplierVO;
import com.sdut.supermarket.utils.JDBCUtil;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class GoodDaoImpl implements IGoodDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());

    @Override
    public List<GoodSupplierVO> selectByPage(GoodQuery goodQuery) {
        //SQL语句：查询那个员工所数的部分
        String sql = "SELECT g.id, g.name, g.num, g.price, g.qgp, s.name sName FROM good AS g INNER JOIN supplier AS s on g.sid=s.id ";
        //查询参数
        List<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(goodQuery.getName())) {
            where += "and name like ? ";
            args.add("%" + goodQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(goodQuery.getSupplier())) {
            where += "and sid = (select id from supplier as s where 1= 1 and s.name = ?) ";
            args.add(goodQuery.getSupplier());
        }
        String limit;
        int offset = (goodQuery.getPage() - 1) * goodQuery.getLimit();
        limit = "order by id desc limit " + offset + "," + goodQuery.getLimit();
        System.out.println(sql + where + limit);
        return jdbcTemplate.query(sql + where + limit, new BeanPropertyRowMapper<>(GoodSupplierVO.class), args.toArray());
    }

    @Override
    public Long selectTotalCount(GoodQuery goodQuery) {
        String sql = "select count(*) from good ";
        return jdbcTemplate.queryForObject(sql, Long.class);
    }

    @Override
    public Integer deleteById(Integer id) {
        String sql = "delete from good where id=?";
        return jdbcTemplate.update(sql, id);
    }

    @Override
    public Integer deleteAll(Integer[] ids) {
        String sql = "delete from supplier where id in(";
        for (Integer id : ids) {
            sql += "?,";
        }
        sql = sql.substring(0, sql.length() - 1);
        sql += ")";
        return jdbcTemplate.update(sql, ids);
    }

    @Override
    public Integer add(Good emp) {
        String sql = "insert into good(name,num,price,qgp,sid) values(?,?,?,?,?)";
        return jdbcTemplate.update(sql, emp.getName(), emp.getNum(), emp.getPrice(), emp.getQgp(), emp.getSid());
    }

    @Override
    public Good selectById(int id) {
        String sql = "select id,name,num,price,qgp,sid from good where id=?";
        List<Good> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Good.class), id);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public Integer update(Good emp) {
        String sql = "update good set name=?,num=?,price=?,qgp=?,sid=? where id=?";
        return jdbcTemplate.update(sql, emp.getName(), emp.getNum(), emp.getPrice(), emp.getQgp(), emp.getSid());
    }
}
