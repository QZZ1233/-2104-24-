package com.sdut.supermarket.dao.impl;

import com.sdut.supermarket.dao.IEmpDao;
import com.sdut.supermarket.pojo.Emp;
import com.sdut.supermarket.pojo.query.EmpQuery;
import com.sdut.supermarket.pojo.vo.EmpDeptVO;
import com.sdut.supermarket.utils.JDBCUtil;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class EmpDaoImpl implements IEmpDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());

    @Override
    public List<Emp> selectAll() {
        String sql = "select id,name,dept_id,email,phone from emp";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Emp.class));
    }

    @Override
    public List<EmpDeptVO> selectByPage(EmpQuery empQuery) {
        //SQL语句：查询那个员工所数的部分
        String sql = "SELECT e.id,e.name,e.email,e.phone," +
                "d.id deptId, d.name deptName FROM emp " +
                "AS e INNER JOIN dept AS d on e.dept_id=d.id ";

        //查询参数
        List<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(empQuery.getName())) {
            where += "and name like ?";
            args.add("%" + empQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(empQuery.getEmail())) {
            where += "and email=?";
            args.add(empQuery.getEmail());
        }
        if (!StringUtils.isEmpty(empQuery.getPhone())) {
            where += "and phone=?";
            args.add(empQuery.getPhone());
        }

        String limit;
        int offset = (empQuery.getPage() - 1) * empQuery.getLimit();
        limit = "order by id desc limit " + offset + "," + empQuery.getLimit();
        System.out.println(sql + limit + where);

        return jdbcTemplate.query(sql + where + limit, new BeanPropertyRowMapper<>(EmpDeptVO.class), args.toArray());
    }

    @Override
    public Long selectTotalCount(EmpQuery empQuery) {
        // <where> <if></if> </where>
        //这三个搜索条件应该是有值才拼接上，没有值就不拼接
        String sql = "select count(*) from emp ";

        //查询参数
        ArrayList<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(empQuery.getName())) {
            where += "and name like ?";
            args.add("%" + empQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(empQuery.getEmail())) {
            where += "and email=?";
            args.add(empQuery.getEmail());
        }
        if (!StringUtils.isEmpty(empQuery.getPhone())) {
            where += "and phone=?";
            args.add(empQuery.getPhone());
        }

        return jdbcTemplate.queryForObject(sql + where, Long.class, args.toArray());
    }

    @Override
    public Integer deleteById(Integer id) {
        String sql = "delete from emp where id=?";
        return jdbcTemplate.update(sql, id);
    }

    @Override
    public Integer deleteAll(Integer[] ids) {
        String sql = "delete from emp where id in(";
        for (Integer id : ids) {
            sql += "?,";
        }
        sql = sql.substring(0, sql.length() - 1);
        sql += ")";
        return jdbcTemplate.update(sql, ids);
    }

    @Override
    public Integer add(Emp emp) {
        String sql = "insert into emp(name,dept_id,email,phone) values(?,?,?,?)";
        return jdbcTemplate.update(sql, emp.getName(), emp.getDeptId(), emp.getEmail(), emp.getPhone());
    }

    @Override
    public Emp selectById(int id) {
        String sql = "select id,name,dept_id,email,phone from emp where id=?";
        List<Emp> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Emp>(Emp.class), id);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public Integer update(Emp emp) {
        String sql = "update emp set name=?,dept_id=?,email=?,phone=? where id=?";
        return jdbcTemplate.update(sql, emp.getName(), emp.getDeptId(), emp.getEmail(), emp.getPhone(), emp.getId());
    }
}
