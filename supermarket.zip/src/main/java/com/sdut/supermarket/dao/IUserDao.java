package com.sdut.supermarket.dao;

import com.sdut.supermarket.pojo.User;
import com.sdut.supermarket.pojo.query.UserQuery;

import java.util.List;

public interface IUserDao {
    List<User> selectAll();

    List<User> selectByPage(UserQuery userQuery);

    Long selectTotalCount(UserQuery userQuery);

    Integer deleteById(Integer id);

    Integer deleteAll(Integer[] ids);

    Integer add(User user);

    User selectById(int id);

    Integer update(User user);

    User login(String name, String password);

    Integer updateStatus(String id, Integer status);
}
