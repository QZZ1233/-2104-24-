package com.sdut.supermarket.dao;

import com.sdut.supermarket.pojo.Emp;
import com.sdut.supermarket.pojo.query.EmpQuery;
import com.sdut.supermarket.pojo.vo.EmpDeptVO;

import java.util.List;

public interface IEmpDao {
    List<Emp> selectAll();

    List<EmpDeptVO> selectByPage(EmpQuery empQuery);

    Long selectTotalCount(EmpQuery empQuery);

    Integer deleteById(Integer id);

    Integer deleteAll(Integer[] ids);

    Integer add(Emp emp);

    Emp selectById(int id);

    Integer update(Emp emp);
}
