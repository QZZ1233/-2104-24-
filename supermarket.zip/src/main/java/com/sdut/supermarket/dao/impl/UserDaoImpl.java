package com.sdut.supermarket.dao.impl;

import com.sdut.supermarket.dao.IUserDao;
import com.sdut.supermarket.pojo.User;
import com.sdut.supermarket.pojo.query.UserQuery;
import com.sdut.supermarket.utils.JDBCUtil;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements IUserDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());

    @Override
    public List<User> selectAll() {
        String sql = "select id, name, password, email, phone from user";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class));
    }

    @Override
    public List<User> selectByPage(UserQuery userQuery) {
        String sql = "select id, name, type, password, email, phone, status, gmt_create, gmt_modified from user ";

        //查询参数
        ArrayList<Object> args = new ArrayList<>();
        String where = "where 1 = 1 ";
        if (!StringUtils.isEmpty(userQuery.getName())) {
            where += "and name like ?";
            args.add("%" + userQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(userQuery.getEmail())) {
            where += "and email=?";
            args.add(userQuery.getEmail());
        }
        if (!StringUtils.isEmpty(userQuery.getPhone())) {
            where += "and phone=?";
            args.add(userQuery.getPhone());
        }
        if (userQuery.getType() != null) {
            where += "and type=?";
            args.add(userQuery.getType());
        }
        if (userQuery.getBeginDate() != null && userQuery.getEndDate() != null) {
            where += "and gmt_create between ? and ? ";
            args.add(userQuery.getBeginDate());
            args.add(userQuery.getEndDate());
        }

        String limit;
        int offset = (userQuery.getPage() - 1) * userQuery.getLimit();
        limit = " order by id desc limit " + offset + "," + userQuery.getLimit();

        return jdbcTemplate.query(sql + where + limit, new BeanPropertyRowMapper<>(User.class), args.toArray());
    }

    @Override
    public Long selectTotalCount(UserQuery userQuery) {
        // <where> <if></if> </where>
        //这三个搜索条件应该是有值才拼接上，没有值就不拼接
        String sql = "select count(*) from user ";

        //查询参数
        List<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(userQuery.getName())) {
            where += "and name like ?";
            args.add("%" + userQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(userQuery.getEmail())) {
            where += "and email=?";
            args.add(userQuery.getEmail());
        }
        if (!StringUtils.isEmpty(userQuery.getPhone())) {
            where += "and phone=?";
            args.add(userQuery.getPhone());
        }
        if (userQuery.getType() != null) {
            where += "and type=?";
            args.add(userQuery.getType());
        }
        if (userQuery.getBeginDate() != null && userQuery.getEndDate() != null) {
            where += "and gmt_create between ? and ? ";
            args.add(userQuery.getBeginDate());
            args.add(userQuery.getEndDate());
        }

        return jdbcTemplate.queryForObject(sql + where, Long.class, args.toArray());
    }

    @Override
    public Integer deleteById(Integer id) {
        String sql = "delete from user where id=?";
        return jdbcTemplate.update(sql, id);
    }

    @Override
    public Integer deleteAll(Integer[] ids) {
        StringBuilder sql = new StringBuilder("delete from user where id in(");
        for (Integer id : ids) {
            sql.append("?,");
        }
        sql = new StringBuilder(sql.substring(0, sql.length() - 1));
        sql.append(")");
        return jdbcTemplate.update(sql.toString(), ids);
    }

    @Override
    public Integer add(User user) {
        String sql = "insert into user(name,password,email,phone,avatar,type) values(?,?,?,?,?,?)";
        return jdbcTemplate.update(sql, user.getName(),
                user.getPassword(), user.getEmail(),
                user.getPhone(), user.getAvatar(), user.getType());
    }

    @Override
    public User selectById(int id) {
        String sql = "select id,name,password,email,phone from user where id=?";
        List<User> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class), id);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public Integer update(User user) {
        String sql = "update user set name=?,password=?,email=?,phone=?,avatar=? where id=?";
        return jdbcTemplate.update(sql, user.getName(), user.getPassword(), user.getEmail(), user.getPhone(), user.getAvatar(), user.getId());
    }

    @Override
    public User login(String name, String password) {
        String sql = "select id,name,password,email,phone,type,status from user where name=? and password=?";
        List<User> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class), name, password);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public Integer updateStatus(String id, Integer status) {
        String sql = "update user set status=? where id=?";
        //返回更新的条数
        return jdbcTemplate.update(sql, status, id);
    }
}
