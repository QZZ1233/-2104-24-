package com.sdut.supermarket.dao.impl;


import com.sdut.supermarket.dao.IDeptDao;
import com.sdut.supermarket.pojo.Dept;
import com.sdut.supermarket.pojo.query.DeptQuery;
import com.sdut.supermarket.pojo.vo.DeptCountVO;
import com.sdut.supermarket.utils.JDBCUtil;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class DeptDaoImpl implements IDeptDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JDBCUtil.getDataSource());

    @Override
    public List<Dept> selectAll() {
        String sql = "select id, name, addr from dept";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Dept.class));
    }

    @Override
    public List<Dept> selectByPage(DeptQuery deptQuery) {
        String sql = "select id,name,addr from dept ";

        //查询参数
        List<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(deptQuery.getName())) {
            where += "and name like ?";
            args.add("%" + deptQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(deptQuery.getAddr())) {
            where += "and addr=?";
            args.add(deptQuery.getAddr());
        }

        String limit;
        int offset = (deptQuery.getPage() - 1) * deptQuery.getLimit();
        limit = "order by id desc limit " + offset + "," + deptQuery.getLimit();

        return jdbcTemplate.query(sql + where + limit, new BeanPropertyRowMapper<>(Dept.class), args.toArray());
    }

    @Override
    public Long selectTotalCount(DeptQuery deptQuery) {
        // <where> <if></if> </where>
        //这三个搜索条件应该是有值才拼接上，没有值就不拼接
        String sql = "select count(*) from dept ";

        //查询参数
        List<Object> args = new ArrayList<>();
        String where = "where 1=1 ";
        if (!StringUtils.isEmpty(deptQuery.getName())) {
            where += "and name like ?";
            args.add("%" + deptQuery.getName() + "%");
        }
        if (!StringUtils.isEmpty(deptQuery.getAddr())) {
            where += "and addr=?";
            args.add(deptQuery.getAddr());
        }

        return jdbcTemplate.queryForObject(sql + where, Long.class, args.toArray());
    }

    @Override
    public Integer deleteById(Integer id) {
        String sql = "delete from dept where id=?";
        return jdbcTemplate.update(sql, id);
    }

    @Override
    public Integer deleteAll(Integer[] ids) {
        String sql = "delete from dept where id in(";
        for (Integer id : ids) {
            sql += "?,";
        }
        sql = sql.substring(0, sql.length() - 1);
        sql += ")";
        return jdbcTemplate.update(sql, ids);
    }

    @Override
    public Integer add(Dept dept) {
        String sql = "insert into dept(name,addr) values(?,?)";
        return jdbcTemplate.update(sql, dept.getName(), dept.getAddr());
    }

    @Override
    public Dept selectById(int id) {
        String sql = "select id,name,addr from dept where id=?";
        List<Dept> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Dept.class), id);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public Integer update(Dept dept) {
        String sql = "update dept set name=?,addr=? where id=?";
        return jdbcTemplate.update(sql, dept.getName(), dept.getAddr(), dept.getId());
    }

    @Override
    public List<DeptCountVO> selectDeptCount() {
        String sql = "SELECT d.name,count(*) as value FROM emp AS e INNER JOIN dept AS d on e.dept_id=d.id GROUP BY d.id";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(DeptCountVO.class));
    }
}
