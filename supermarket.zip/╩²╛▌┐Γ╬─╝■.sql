/*
 Navicat Premium Data Transfer

 Source Server         : db8
 Source Server Type    : MySQL
 Source Server Version : 80012
 Source Host           : localhost:3306
 Source Schema         : hotel

 Target Server Type    : MySQL
 Target Server Version : 80012
 File Encoding         : 65001

 Date: 11/01/2023 15:26:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for dept
-- ----------------------------
DROP TABLE IF EXISTS `dept`;
CREATE TABLE `dept`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '员工编号',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '部门名',
  `addr` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '部门地址',
  `deleted` tinyint(4) NOT NULL DEFAULT 1 COMMENT '逻辑删除 1（true）未删除， 0（false）已删除',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dept
-- ----------------------------
INSERT INTO `dept` VALUES (1, '客房部', '201', 1, '2022-12-21 14:26:10', '2022-12-21 14:26:10');
INSERT INTO `dept` VALUES (2, '后勤部', '202', 1, '2022-12-21 14:26:21', '2022-12-21 14:26:21');
INSERT INTO `dept` VALUES (3, 'IT部', '204', 1, '2022-12-21 14:26:40', '2022-12-21 14:26:53');
INSERT INTO `dept` VALUES (4, '财务部', '222', 1, '2022-12-21 14:38:53', '2022-12-21 14:38:53');

-- ----------------------------
-- Table structure for emp
-- ----------------------------
DROP TABLE IF EXISTS `emp`;
CREATE TABLE `emp`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '员工编号',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '员工名',
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮件',
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `dept_id` bigint(20) NULL DEFAULT NULL COMMENT '所属部门编号',
  `deleted` tinyint(4) NOT NULL DEFAULT 1 COMMENT '逻辑删除 1（true）未删除， 0（false）已删除',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `dept_id`(`dept_id`) USING BTREE,
  CONSTRAINT `emp_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `dept` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of emp
-- ----------------------------
INSERT INTO `emp` VALUES (1, 'zhangsan', '12', '1', 1, 1, '2022-12-21 14:28:43', '2022-12-21 14:28:43');
INSERT INTO `emp` VALUES (2, '财神爷', '12', '1', 4, 1, '2022-12-21 14:39:10', '2022-12-21 14:39:10');
INSERT INTO `emp` VALUES (3, 'lisi', '1', '2', 4, 1, '2022-12-21 14:39:47', '2022-12-21 14:39:47');
INSERT INTO `emp` VALUES (4, 'zhaoliu', '211', '1', 3, 1, '2022-12-21 14:50:05', '2022-12-21 14:50:05');
INSERT INTO `emp` VALUES (5, '小新', '2', '2', 1, 1, '2022-12-21 15:46:50', '2023-01-05 09:55:51');

-- ----------------------------
-- Table structure for good
-- ----------------------------
DROP TABLE IF EXISTS `good`;
CREATE TABLE `good`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品名称',
  `num` int(11) NOT NULL COMMENT '商品数量',
  `price` float(10, 2) NOT NULL COMMENT '商品价格',
  `qgp` datetime(0) NOT NULL COMMENT '保质期',
  `sid` int(11) NOT NULL COMMENT '供应商编号',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `good_supplier_fk`(`sid`) USING BTREE,
  CONSTRAINT `good_supplier_fk` FOREIGN KEY (`sid`) REFERENCES `supplier` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of good
-- ----------------------------
INSERT INTO `good` VALUES (1, '波尼亚火腿肠', 56564, 11.56, '2022-12-31 20:57:08', 1);
INSERT INTO `good` VALUES (2, '盼盼梅尼耶蛋糕', 1225, 12.36, '2023-01-13 09:57:04', 1);
INSERT INTO `good` VALUES (3, '雅诗兰黛小棕瓶', 123, 434.00, '2022-11-12 23:11:12', 2);

-- ----------------------------
-- Table structure for supplier
-- ----------------------------
DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '供应商id',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商名称',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商邮箱',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商电话',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of supplier
-- ----------------------------
INSERT INTO `supplier` VALUES (1, '波尼亚', '6666666@qq.com', '19546301428');
INSERT INTO `supplier` VALUES (2, '旺旺食品有限公司', 'valentin.johnston@hotmail.com', '15263047445');
INSERT INTO `supplier` VALUES (3, '万福食品有限公司', 'tequila.purdy@hotmail.com', '15263047445');
INSERT INTO `supplier` VALUES (4, '三只松鼠食品有限公司', 'gustavo.steuber@yahoo.com', '15263047445');
INSERT INTO `supplier` VALUES (5, '王老吉食品有限公司', 'lenny.medhurst@gmail.com', '15263047445');
INSERT INTO `supplier` VALUES (6, '加多宝食品有限公司', 'oda.lesch@hotmail.com', '15263047445');
INSERT INTO `supplier` VALUES (7, '联合利华有限公司', 'maryjane.okuneva@yahoo.com', '15263047445');
INSERT INTO `supplier` VALUES (8, '金锣食品有限公司', 'franklyn.considine@hotmail.com', '15263047445');
INSERT INTO `supplier` VALUES (9, '水润坊化妆品公司', 'angelia.moore@gmail.com', '15263047445');
INSERT INTO `supplier` VALUES (10, '良品铺子食品有限公司', 'lenny.mraz@gmail.com', '15263047445');
INSERT INTO `supplier` VALUES (11, '养生堂', 'yangshengtang@jpa.com', '19997826556');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码',
  `email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮件',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户头像',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态（1：正常 0：停用）',
  `deleted` tinyint(4) NOT NULL DEFAULT 1 COMMENT '逻辑删除 1（true）未删除， 0（false）已删除',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `type` tinyint(4) NULL DEFAULT NULL COMMENT '1-超级管理员 2-普通管理员',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 68 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (23, 'zhangsan', '31E662302F47FA8C0CE3A51C5B25C203', '4', '4', '4', 1, 1, '2022-12-19 08:18:05', '2022-12-22 09:51:15', 1);
INSERT INTO `user` VALUES (49, 'lisi', '202CB962AC59075B964B07152D234B70', '11', '1', '', 1, 1, '2022-12-20 09:33:02', '2022-12-22 09:51:16', 2);
INSERT INTO `user` VALUES (52, 'wangwu', '3D74B401A5FA1B2B18BCD3804FC9D5A7', '11', '', '', 1, 1, '2022-12-21 08:10:38', '2022-12-22 09:51:17', 2);
INSERT INTO `user` VALUES (53, '2', '2', '2', '2', NULL, 1, 1, '2022-12-21 08:51:30', '2022-12-22 09:51:18', 1);
INSERT INTO `user` VALUES (54, '4', '4', '4', NULL, NULL, 1, 1, '2022-12-21 08:51:35', '2022-12-22 09:51:21', 2);
INSERT INTO `user` VALUES (55, '4', '4', NULL, NULL, NULL, 1, 1, '2022-12-21 08:51:38', '2022-12-22 09:51:19', 2);
INSERT INTO `user` VALUES (56, '5', '5', '5', NULL, NULL, 1, 1, '2022-12-21 08:51:42', '2022-12-22 09:51:22', 2);
INSERT INTO `user` VALUES (57, '6', '6', '6', NULL, NULL, 1, 1, '2022-12-21 08:51:45', '2022-12-22 09:51:25', 1);
INSERT INTO `user` VALUES (58, '7', '7', '7', NULL, NULL, 1, 1, '2022-12-21 08:51:49', '2022-12-22 09:51:24', 1);
INSERT INTO `user` VALUES (59, '8', '8', '8', NULL, NULL, 1, 1, '2022-12-21 08:51:52', '2022-12-22 09:51:26', 1);
INSERT INTO `user` VALUES (60, '9', '9', '9', NULL, NULL, 0, 1, '2022-12-21 08:51:56', '2022-12-23 08:27:48', 1);
INSERT INTO `user` VALUES (61, '99', '99', '99', NULL, NULL, 1, 1, '2022-12-21 08:52:00', '2022-12-22 09:51:28', 1);
INSERT INTO `user` VALUES (62, '0', '0', '0', NULL, NULL, 1, 1, '2022-12-21 08:52:03', '2022-12-22 09:51:30', 1);
INSERT INTO `user` VALUES (63, '66', '66', NULL, NULL, NULL, 1, 1, '2022-12-21 08:52:07', '2022-12-22 09:51:31', 1);
INSERT INTO `user` VALUES (64, '7', '8', NULL, NULL, NULL, 0, 1, '2022-12-21 08:52:10', '2022-12-22 15:34:34', 1);
INSERT INTO `user` VALUES (65, 'xiaoli', 'E0D6EAE3D9F7DB604B0589E65709ADE2', '12', '11', '', 0, 1, '2022-12-21 10:15:18', '2022-12-22 15:34:34', 1);
INSERT INTO `user` VALUES (66, 'ww', '31E662302F47FA8C0CE3A51C5B25C203', '1', '1', '', 1, 1, '2022-12-22 10:01:07', '2022-12-22 15:43:55', 1);
INSERT INTO `user` VALUES (67, 'xx', '31E662302F47FA8C0CE3A51C5B25C203', '1', '1', '', 1, 1, '2022-12-22 10:01:21', '2022-12-23 08:27:17', 2);
INSERT INTO `user` VALUES (68, '3', '45F64462373F912E188F4A649F34FBF4', '3', '3', '', 0, 1, '2022-12-22 14:42:49', '2022-12-23 08:27:44', 2);

SET FOREIGN_KEY_CHECKS = 1;
